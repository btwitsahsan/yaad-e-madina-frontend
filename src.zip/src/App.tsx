import React, { useState } from "react";
import "./App.css";
import Sidebar from "./components/sidebar/Sidebar";
import Navbar from "./components/navbar/Navbar";
import Dashboard from "./pages/dashboard/Dashboard";
import Layout from "./pages/Layout";
import Categories from "./pages/categories/Categories";
import NaatKhawan from "./pages/naatkhawan/Naatkhawan";
import Album from "./pages/album/Album";
import { Route, Routes } from "react-router-dom";
import AdminList from "./pages/adminlist/AdminList";
import Playlist from "./pages/playlist/Playlist";
import SubscriptionPlan from "./pages/subscriptionPlan/SubscriptionPlan";
import Transactions from "./pages/transactions/Transactions";
import Suggestions from "./pages/suggestions/Suggestions";
import Reports from "./pages/reports/Reports";
import AddCategory from "./pages/categories/AddCategory";
import AddNaatKhawan from "./pages/naatkhawan/AddNaatkhawan";
import AddAlbum from "./pages/album/AddAlbum";
import Slider from "./pages/slider/Slider";
import AddSlider from "./pages/slider/AddSlider";
import HomeSections from "./pages/homesections/HomeSections";
import AddSections from "./pages/homesections/AddSections";
import AddAdmin from "./pages/adminlist/AddAdmin";
import Users from "./pages/users/Users";
import AddUser from "./pages/users/AddUser";
import AddPlaylist from "./pages/playlist/AddPlaylist";
import AddSubscriptionPlan from "./pages/subscriptionPlan/AddSubscriptionPlan";
import PageList from "./pages/addpages/PageList";
import AddPage from "./pages/addpages/AddPage";
import Audios from "./pages/audios/Audios";
import AddAudio from "./pages/audios/AddAudio";
import OneSignalNotification from "./settings/OneSignalNotification";
import AppUpdate from "./settings/AppUpdate";
import OtherSettings from "./settings/OtherSettings";
import Footer from "./components/footer/Footer";
import SignIn from "./pages/Auths/SignIn";
import SignUp from "./pages/Auths/SignUp";

const App: React.FC = () => {
  const [sidebarToggle, setSidebarToggle] = useState(false);
  return (
    <>
      <div className="flex">
        <Sidebar sidebarToggle={sidebarToggle} />
        <Navbar
          sidebarToggle={sidebarToggle}
          setSidebarToggle={setSidebarToggle}
        />
      </div>

      <Layout sidebarToggle={sidebarToggle}>
        <Routes>
          <Route path="/adminLogin" element={<SignIn />} />
          {/* <Route path="/createAdmin" element={<SignUp />} /> */}

          <Route path="/" element={<Dashboard />} />
          <Route path="/addcategory" element={<AddCategory />} />
          <Route path="/categories" element={<Categories />} />

          <Route path="/naatkhawan" element={<NaatKhawan />} />
          <Route path="/addnaatkhawan" element={<AddNaatKhawan />} />

          <Route path="/album" element={<Album />} />
          <Route path="/addalbum" element={<AddAlbum />} />

          <Route path="/playlist" element={<Playlist />} />
          <Route path="/addplaylist" element={<AddPlaylist />} />

          <Route path="/audios" element={<Audios />} />
          <Route path="/addaudio" element={<AddAudio />} />

          <Route path="/slider" element={<Slider />} />
          <Route path="/addslider" element={<AddSlider />} />

          <Route path="/homesections" element={<HomeSections />} />
          <Route path="/addsections" element={<AddSections />} />

          <Route path="/users" element={<Users />} />
          <Route path="/adduser" element={<AddUser />} />

          <Route path="/subadmin" element={<AdminList />} />
          <Route path="/addadmin" element={<AddAdmin />} />

          <Route path="/subscriptionplan" element={<SubscriptionPlan />} />
          <Route
            path="/addsubscriptionplan"
            element={<AddSubscriptionPlan />}
          />

          <Route path="/transactions" element={<Transactions />} />
          <Route path="/suggestions" element={<Suggestions />} />

          {/* <Route path="/reports" element={<Reports />} /> */}

          <Route path="/pages" element={<PageList />} />
          <Route path="/addpage" element={<AddPage />} />

          <Route
            path="/onesignalnotification"
            element={<OneSignalNotification />}
          />
          <Route path="/appupdatepopup" element={<AppUpdate />} />
          <Route path="/othersettings" element={<OtherSettings />} />
        </Routes>
      </Layout>
      <Footer
        sidebarToggle={sidebarToggle}
        setSidebarToggle={setSidebarToggle}
      />

      {/* <Artists/> */}
    </>
  );
};

export default App;
