import Cookies from "js-cookie";

export function encryptCookie(name: any, value: any) {
  const encryptedValue = btoa(value);
  document.cookie = `${name}=${encryptedValue}; path=/`;
}

export function decryptCookie(name: any) {
  const cookies = document.cookie.split(";");
  for (let cookie of cookies) {
    const [cookieName, cookieValue] = cookie.split("=");
    if (cookieName.trim() === name) {
      return atob(cookieValue);
    }
  }
  return null;
}

export function clearAllCookies() {
  const cookies = Cookies.get();

  for (const cookie in cookies) {
    Cookies.remove(cookie);
  }
}
