import React, { useEffect, useState } from "react";
import { FaEdit, FaSearch } from "react-icons/fa";
import { MdDelete } from "react-icons/md";
import { useNavigate } from "react-router-dom";
import { getNaatKhawans, deleteNaatKhawan } from "../../network/api"; // Import getNaatKhawans and deleteNaatKhawan
import swal from "sweetalert";
import Loader from "../../Loader"; // Import Loader

interface NaatKhawan {
  id: string;
  name: string;
  image: string;
}

const NaatKhawans: React.FC = () => {
  const [naatKhawans, setNaatKhawans] = useState<NaatKhawan[]>([]);
  const [loading, setLoading] = useState<boolean>(true); // Loader state
  const navigate = useNavigate();

  const addNaatKhawanHandler = () => {
    navigate("/addnaatkhawan");
  };

  useEffect(() => {
    const fetchNaatKhawansData = async () => {
      setLoading(true); // Show loader
      try {
        const data = await getNaatKhawans();
        setNaatKhawans(data);
      } catch (error) {
        console.error("Failed to fetch Naat Khawans", error);
        swal("Error", "Failed to fetch Naat Khawans", "error");
      } finally {
        setLoading(false); // Hide loader
      }
    };

    fetchNaatKhawansData();
  }, []);

  const deleteNaatKhawanHandler = async (id: string) => {
    swal({
      title: "Are you sure?",
      text: "Once deleted, you will not be able to recover this Naat Khawan!",
      icon: "warning",
      dangerMode: true,
    }).then(async (willDelete) => {
      if (willDelete) {
        try {
          await deleteNaatKhawan(id);
          setNaatKhawans((prevNaatKhawans) =>
            prevNaatKhawans.filter((nk) => nk.id !== id)
          );
          swal("Success", "Naat Khawan has been deleted!", "success");
        } catch (error) {
          console.error("Failed to delete Naat Khawan", error);
          swal("Error", "Failed to delete Naat Khawan", "error");
        }
      }
    });
  };

  return (
    <div className="w-full bg-gray-800 rounded p-4">
      <div className="flex justify-between items-center">
        <div className="relative md:w-64">
          <span className="relative md:absolute inset-y-0 right-0 flex items-center pr-2 z-10">
            <button className="p-1 focus:outline-none text-white md:text-white">
              <FaSearch />
            </button>
          </span>
          <input
            type="text"
            placeholder="Search By Title..."
            className="w-full h-11 px-4 py-1 pr-12 rounded shadow text-white outline-none hidden md:block backdrop-blur-sm bg-white/10"
          />
        </div>
        <button
          onClick={addNaatKhawanHandler}
          className="bg-green-600 text-white rounded p-2 font-semibold"
        >
          + Add Naat Khawan
        </button>
      </div>

      {loading ? (
        <Loader />
      ) : naatKhawans.length === 0 ? (
        <div className="flex justify-center items-center h-64">
          <span className="text-white text-xl">No Naat Khawans available</span>
        </div>
      ) : (
        <div className="flex flex-wrap justify-center md:justify-start gap-2 pt-3">
          {naatKhawans.map((naatKhawan) => (
            <div
              key={naatKhawan.id}
              className="flex flex-col w-full md:w-72 bg-slate-700 rounded-lg overflow-hidden"
            >
              <div className="w-full">
                <img
                  className="w-full h-64"
                  src={naatKhawan.image}
                  alt={naatKhawan.name}
                />
              </div>
              <div className="flex flex-col gap-3 w-full p-4">
                <div>
                  <span className="text-white text-xl font-semibold tracking-wider">
                    {naatKhawan.name}
                  </span>
                </div>
                <div className="flex justify-between ">
                  <div>
                    <button className="rounded-full bg-green-600 text-white p-2">
                      <FaEdit />
                    </button>
                    <button
                      className="rounded-full bg-red-600 text-white p-2 ml-1"
                      onClick={() => deleteNaatKhawanHandler(naatKhawan.id)}
                    >
                      <MdDelete />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default NaatKhawans;
