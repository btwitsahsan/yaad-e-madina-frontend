import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { AdminLogin } from "../../network/api";
import { encryptCookie } from "../../utils/cookie";

const SignIn: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const resp = await AdminLogin({ email, password });

      if (resp.success) {
        const { token } = resp;
        encryptCookie("token", token);
        navigate("/");
      }else{
        console.log(resp);
      }
    } catch (error) {
      // setErrorMessage("Invalid email or password.");
      console.log("Invalid email or password.");
    }
  };

  return (
    <div className="w-full h-screen flex justify-center items-center bg-gray-800">
      <div className="w-full max-w-md bg-slate-700 rounded-lg p-8">
        <h2 className="text-white text-2xl font-semibold mb-4 text-center">SIGN IN</h2>
        <form onSubmit={handleLogin} className="flex flex-col gap-4">
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="p-2 rounded bg-gray-600 text-white"
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="p-2 rounded bg-gray-600 text-white"
            required
          />
          <button type="submit" className="bg-red-600 text-white rounded p-2 font-semibold">
            Sign In
          </button>
        </form>
      </div>
    </div>
  );
};

export default SignIn;
