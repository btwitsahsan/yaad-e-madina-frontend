import axios from "axios";
import { decryptCookie, encryptCookie } from "../utils/cookie";

// const DOMAIN = "http://127.0.0.1:4000/api";
const DOMAIN = "https://yaad-e-madina-admin-backend.vercel.app/api";


export const AdminLogin = async (data: any) => {
  try {
    const resp = await axios({
      url: `${DOMAIN}/admin/login`,
      method: "POST",
      data: data,
    });

    if (resp.status === 200) {
      const token = await resp.data.token;
      console.log(token);
      encryptCookie("token", token) // Store the token in cookies
      return resp.data;
    }
    return null;
  } catch (err: any) {
    return err.message;
  }
};

export const CreateCategory = async (data: any) => {
  try {
    const resp = await axios({
      url: `${DOMAIN}/createCategory`,
      method: "POST",
      data: data,
      headers:{
        authorization: decryptCookie("token")
      }
    });

    if (resp.status === 200) return resp.data;
    return null;
  } catch (err: any) {
    return err.message;
  }
};


export const getCategories = async () => {
  try {
    const resp = await axios({
      url:`${DOMAIN}/getAllCategories`,
      method: "POST",
      headers:{
        authorization: decryptCookie("token")
      }
    });
    return resp.data.categories;
  } catch (error) {
    console.error("Error fetching categories:", error);
    throw error;
  }
};

export const deleteCategory = async (id:any) => {
  try {
    const resp = await axios({
      url:`${DOMAIN}/deleteCategory/${id}`,
      method: "POST",
      headers:{
        authorization: decryptCookie("token")
      }
    });
    return resp.data.categories;
  } catch (error) {
    console.error("Error deleting categories:", error);
    throw error;
  }
};




// Naat Khawan 
export const CreateNaatKhawan = async (data: any) => {
  try {
    const resp = await axios({
      url: `${DOMAIN}/createNaatKhawan`,
      method: "POST",
      data: data,
      headers:{
        authorization: decryptCookie("token") 
      }
    });

    if (resp.status === 200) return resp.data;
    return null;
  } catch (err: any) {
    return err.message;
  }
};



export const getNaatKhawans = async () => {
  try {
    const resp = await axios({
      url:`${DOMAIN}/getAllNaatKhawans`,
      method: "POST",
      headers:{
        authorization: decryptCookie("token")
      }
    });
    return resp.data.naatKhawans;
  } catch (error) {
    console.error("Error fetching Naat Khawans:", error);
    throw error;
  }
};


export const deleteNaatKhawan = async (id:any) => {
  try {
    const resp = await axios({
      url:`${DOMAIN}/deleteNaatKhawan/${id}`,
      method: "POST",
      headers:{
        authorization: decryptCookie("token")
      }
    });
    return resp.data.categories;
  } catch (error) {
    console.error("Error deleting Naat Khawan:", error);
    throw error;
  }
};



// export const createAlbum = async (albumData:any) => {
//   try {
//     // const response = await axios.post(`${DOMAIN}/api/albums`, albumData);
//     // return response.data;
//     console.log(albumData);
//   } catch (error) {
//     console.error("Error creating album:", error);
//     throw error;
//   }
// };