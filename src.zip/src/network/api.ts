import axios from "axios";

const DOMAIN = "http://127.0.0.1:4000/api"

const headers = {
    "x-api-key": "d108b40a-990d-4130-a977-fac12ed019c1",
  };

export const CreateAdmin = async (data: any) => {
    try {
      const resp = await axios({
        url: `${DOMAIN}/owner/createAdmin`,
        method: "POST",
        data: data,
        headers
      });
    //   console.log(resp.data);
      if (resp.status == 200) return resp.data;
      return null;
    } catch (err: any) {
      return err.message;
    }
  };
  

export const AdminLogin = async (data: any) => {
    try {
      const resp = await axios({
        url: `${DOMAIN}/admin/login`,
        method: "POST",
        data: data,
      });
// console.log(resp.data);
      if (resp.status == 200) return resp.data;
      return null;
    } catch (err: any) {
      return err.message;
    }
  };
  
  



